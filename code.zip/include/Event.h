#ifndef _H_EVENT_H_
#define _H_EVENT_H_
#include<TObject.h>
#include<TClass.h>
#include<TF1.h>

class Event{
public:
	Double_t _Et;
	Double_t _eta;
	Double_t _phi;
	Double_t _wstot;			//shower width
	Double_t _weta2;
	Double_t _reta;			//ratio of 3x7 to 7x7 at el_c position
	Double_t _rphi;			//ratio of 3x3 to 3x7
	Double_t _deltaPhi;
	Double_t _deltaEta;
	Double_t _d0;
	Event();
	~Event();
	ClassDef(Event,1);
};
//ClassImp(Event);
//TClass *_Event_fgIsA = (TClass*) 0;
#endif






























