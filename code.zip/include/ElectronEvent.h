#ifndef _H_ELECTRON_EVENT_H_
#define _H_ELECTRON_EVENT_H_
#include<TLorentzVector.h>
#include"ZPrimeClass.h"

class ElectronEvent{
private:
	float getCosTheta();
	void checkEventIsGood();
public:
	int _e1;
	int _e2;
	float _invMass;
	float _diPt;
	float _E;
	float _Px;
	float _Py;
	float _Pz;
	float _P2;
	float _Pt1;
	float _Pt2;
	float _cosThetaStar;
	bool _isGoodEvent;
	bool _truthOK;
	ZPrimeClass *_data;	
	int i(int arg);
	ElectronEvent(int e1, int e2,ZPrimeClass *data);
	ElectronEvent(){}
	~ElectronEvent();
	double getTruthMass();
};

#endif
