#ifndef _H_ELECTRONEVENTMARKER_H
#define _H_ELECTRONEVENTMARKER_H
#include<string>
class ElectronEventMarker{
public:
	static ElectronEventMarker *_EE_looseMarker;
	static ElectronEventMarker *_EE_mediumMarker;
	static ElectronEventMarker *_EE_tightMarker;
	static ElectronEventMarker *_EE_marker;
	static double _EEMARKER_SCALEFACTOR;
	double _EEMARKER_TOT_EVENTS_1;
	double _EEMARKER_INVMASS_2;
	double _EEMARKER_PT_3;
	double _EEMARKER_CHARGE_4;
	double _EEMARKER_ISOLATION_5;
	std::string _name;
	ElectronEventMarker(std::string name);
	void print(double totalEvents);
	void writeToFile(double totalEvents, std::string, std::string destination);
	void reset();
	static void printAll(double totalEvents);
	static void writeAllToFile(double totalEvents, std::string, std::string destination);
	static void resetAll();
};

#endif
