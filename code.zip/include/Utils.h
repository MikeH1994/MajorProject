#pragma once
#ifndef _H_UTILS_H_
#define _H_UTILS_H_

#include<vector>
#include<string>
#include <dirent.h>

class Utils{
private:
public:
	static std::vector<std::string> getFiles(std::string directory, unsigned int maxLength);
	static void getFilesInFolder(std::string path, std::vector<std::string> &,unsigned int maxLength);
	static std::vector<std::string> getFileList(std::string arg1, std::string arg2 = "2", unsigned int maxLength = 100);	
	static std::string getNthSubfolder(std::string directory, int folderNumber);
	static std::string intToString(int arg);
	static std::string doubleToString(double arg);
	static int stringToInt(std::string arg);
	static int getNFolders(std::string directory);
	static std::string MC_ROOT;
	static std::string MC_DYPO_FOLDER;
	static std::string MC_DYPO_FILE;
	static std::string MC_ZPRIME_FOLDER;
	static std::string MC_ZPRIME_FILE;
	static std::string MC_DYEE_FOLDER;
	static std::string MC_DYEE_FILE;
};
#endif
