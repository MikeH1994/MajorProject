#ifndef _H_DATAMANAGER_H_
#define _H_DATAMANAGER_H_
#include "DYpoClass.h"
#include "DYeeClass.h"
#include "ZPrimeClass.h"
#include "ElectronEvent.h"

#include<TROOT.h>
#include<TH1.h>
#include<TCanvas.h>
#include<TH1F.h>
#include<TError.h>
#include<TFile.h>
#include <utility>
#include <iostream>
#include <string>
#include <TGraph.h>
#include <vector>
#include <map>
#include <TApplication.h>

class DataManager{
private:
	std::map<std::string,double> _crossSectionMap;
	std::vector<std::string> _dataPaths;
	std::vector<bool> _elPassesCuts;
	bool _useChargeRequirement;
	TApplication* _app;
	ZPrimeClass *_data;
	std::string _type;
	std::string _ZPrimeFolders[6];
	std::string _ZPrimeBinNames[6];
	std::string _DYeeFolders[15];
	std::string _DYeeBinNames[15];
	std::string _ADDeeFolders[8];
	std::string _ADDeeBinNames[8];
	std::string _TTBarFolders[1];
	std::string _TTBarBinNames[1];
	std::string _DBiWWFolders[1];
	std::string _DBiZZFolders[1];
	std::string _DBiWZFolders[1];
	//////////////////////////////////////
	std::string _DBWWFolders[2];
	std::string _DBWWBinNames[2];
	std::string _DBWZFolders[2];
	std::string _DBWZBinNames[2];
	std::string _DBZZFolders[2];
	std::string _DBZZBinNames[2];
	//////////////////////////////////////
	double _pi;
	template <typename T> bool electronPassesInitialCuts(int index,std::vector<T> *idCriteria);
	bool eventIsForwards(ElectronEvent &e);
	template <typename T> void evaluateElectrons(std::vector<bool> &vector, std::vector<T> *idCriteria);
	template <typename T> std::pair<int,int> getHighestPtIndex(std::vector<bool> &vector, std::vector<T> *idCriteria);
	template <typename T> ElectronEvent getElectronEvent(std::vector<bool> &vector, std::vector<T> *criteria);
	float getCosTheta(ElectronEvent &ee);
	void initialiseCrossSectionMap();
	double getCrossSection(std::string filename);
	void incrementHistogramScaled(TH1D &hist, double val, double scaleFactor);
	void initialiseArrays();
	double getFWHM(TH1D *hist);
	double getPos(int bin1, TH1D* hist);
	double* findHalfBinPositions(TH1D *hist);
public:
	DataManager();
	DataManager(std::vector<std::string> dataPaths);
	~DataManager();
	const void run();
};


DataManager::DataManager(std::vector<std::string> dataPaths){
	_useChargeRequirement = true;
  _app	= new TApplication("App", 0, 0);	
	_dataPaths = dataPaths;
	initialiseCrossSectionMap();
	TChain *ch = new TChain("physics");
	for(unsigned int i = 0; i<1; i++){
		ch->Add(_dataPaths[i].c_str());
	}
	gErrorIgnoreLevel = kFatal;
	_data = new ZPrimeClass(ch);
	_data->Init(ch);
	_data->fChain->SetBranchStatus("*",1);	
	initialiseArrays();
}

template <typename T> bool DataManager::electronPassesInitialCuts(int index,std::vector<T> *idCriteria){
	if (idCriteria->at(index)==0){
		return false;
	}
	float eta = _data->el_cl_eta->at(index);
	if (fabs(eta)>2.47f){
		return false;
	}
	if (fabs(eta)>=1.37 && fabs(eta)<=1.52){
		return false;
	}
	return true;
}

DataManager::DataManager(){
	
}

DataManager::~DataManager(){
	
}

bool DataManager::eventIsForwards(ElectronEvent &ee){
	return ee._cosThetaStar>0;
}

template <typename T> void DataManager::evaluateElectrons(std::vector<bool> &elPassesCuts, std::vector<T> *idCriteria){
	elPassesCuts.clear();
	for(int i = 0; i<_data->el_n; i++){
		elPassesCuts.push_back(false);
	}
	for(int i = 0; i<_data->el_n; i++){
		elPassesCuts[i] = electronPassesInitialCuts(i,idCriteria);
	}	
}

template <typename T> std::pair<int,int> DataManager::getHighestPtIndex(std::vector<bool> &elPassesCuts,std::vector<T> *idCriteria){
	evaluateElectrons(elPassesCuts,idCriteria);	
	int index1 = -1, index2 = -1;
	float max1 = 0, max2 = 0;
	
	if (_useChargeRequirement){
		std::vector<int> posEl;
		std::vector<int> negEl;
		for(int i = 0; i< _data->el_n; i++){
			if (_data->el_charge->at(i) == 1){
				posEl.push_back(i);
			}
			else{
				negEl.push_back(i);
			}
		}
		double sum;
		for (unsigned int i = 0; i<posEl.size(); i++){
			if (elPassesCuts[posEl[i]]){
				for(unsigned int j = 0; j<negEl.size(); j++){
					if (elPassesCuts[negEl[j]]){
						sum = _data->el_pt->at(posEl[i]) + _data->el_pt->at(negEl[j]);
						if (sum>max1){
							index1 = posEl[i];
							index2 = negEl[j];
							max1 = sum;
						}
					}
				}
			}
		}
	}
	else{
		for(int j = 0; j<_data->el_n; j++){
			if (elPassesCuts[j]){
				if (_data->el_pt->at(j)>max1){
					if(index1!=-1){
						max2=max1;
						index2 = index1;
					}
					index1 = j;
					max1 = _data->el_pt->at(j);
				}
				else if(_data->el_pt->at(j)>max2){
					max2 = _data->el_pt->at(j);
					index2 = j;
				}
			}
		}
	}
	return std::pair<int,int>(index1,index2);
}

template <typename T> ElectronEvent DataManager::getElectronEvent(std::vector<bool> &elPassesCuts,std::vector<T> *idCriteria){
	std::pair<int,int> electrons = getHighestPtIndex(elPassesCuts, idCriteria);
	int e1 = electrons.first;
	int e2 = electrons.second;
	ElectronEvent ee(e1,e2,_data);
	if (ee._isGoodEvent){
		getCosTheta(ee);
	}	
	return ee;
}

float DataManager::getCosTheta(ElectronEvent &ee){
		TLorentzVector leadEle(0,0,0,0);
  TLorentzVector subEle(0,0,0,0);

  leadEle.SetPtEtaPhiE(ee._Pt1,_data->el_cl_eta->at(ee._e1),_data->el_cl_phi->at(ee._e1),_data->el_cl_E->at(ee._e1));
  subEle.SetPtEtaPhiE(ee._Pt2,_data->el_cl_eta->at(ee._e2),_data->el_cl_phi->at(ee._e2),_data->el_cl_E->at(ee._e2));

  TLorentzVector ele_minus(0,0,0,0);
  TLorentzVector ele_plus(0,0,0,0);

  if (_data->el_charge->at(ee._e2) == -1 ){
    ele_minus = subEle;
    ele_plus  = leadEle;
  }
  else{
    ele_minus = leadEle;
    ele_plus  = subEle;
  }

  TLorentzVector diElectron =  ele_plus + ele_minus;

  Double_t cosTheta = -999;

  cosTheta = 2*((ele_minus.Pz()*ele_plus.E())-(ele_plus.Pz()*ele_minus.E()))*(1/((diElectron.Mag())*sqrt((diElectron.Mag()*diElectron.Mag()) + (diElectron.Pt()*diElectron.Pt()))));

  if (diElectron.Pz()<0){
		 cosTheta *= -1;
	}
	ee._diPt = diElectron.Pt();
	ee._cosThetaStar = cosTheta;

	return cosTheta;
}

double DataManager::getCrossSection(std::string filename){
	std::map<std::string, double>::iterator i;
	for(i = _crossSectionMap.begin(); i!=_crossSectionMap.end();i++){
		if (filename.find(i->first)!=std::string::npos){
			return i->second;
		}
	}
	std::cout<<("Histogram " + filename + " not found").c_str()<<std::endl;
	throw 0; 
}

void DataManager::incrementHistogramScaled(TH1D &hist, double val, double scaleFactor){
	int bin = hist.FindBin(val);
	hist.SetBinContent(bin,hist.GetBinContent(bin) + scaleFactor);
}

double DataManager::getFWHM(TH1D *hist){
	double *bins = findHalfBinPositions(hist);
	std::cout<<"==========\t"<<bins[0]<<"\t"<<bins[1]<<std::endl;
	return (bins[1]-bins[0]);
}

double* DataManager::findHalfBinPositions(TH1D *hist){
	double halfMax = hist->GetMaximum()/2;
	bool first = false;
	double* returned = new double[2];
	for(int bin = 1; bin<hist->GetNbinsX(); bin++){
		if (!first){
			if (hist->GetBinContent(bin)<halfMax && hist->GetBinContent(bin+1)>halfMax){
				returned[0] = getPos(bin,hist);
				first = true;
			}
		}
		else{
			if (hist->GetBinContent(bin)>halfMax && hist->GetBinContent(bin+1)<halfMax){
				returned[1] = getPos(bin,hist);
			}
		}
	}
	return returned;
}

double DataManager::getPos(int bin1, TH1D* hist){
	int bin2 = bin1+1;
	double hMax = hist->GetMaximum()/2;
	double dydx = (hist->GetBinContent(bin2)-hist->GetBinContent(bin1))/(hist->GetBinCenter(bin2)-hist->GetBinCenter(bin1));
	double deltaX = (hMax-hist->GetBinContent(bin1))/dydx;
	return deltaX + hist->GetBinCenter(bin1);
}

void DataManager::initialiseCrossSectionMap(){
	// Cross-Sections in Pb

  // Flat Graviton
  _crossSectionMap["FlatG1"] = 7.1941e4;
  _crossSectionMap["FlatG2"] = 5.1238e4;
  _crossSectionMap["FlatG3"] = 1.2928e3;

  // Zee
  _crossSectionMap["Z"] = 1109.9;

  // Drell-Yan
  _crossSectionMap["DYee_120M180"] = 9.8460;
  _crossSectionMap["DYee_180M250"] = 1.5710;
  _crossSectionMap["DYee_250M400"] = 0.5492;
  _crossSectionMap["DYee_400M600"] = 0.08966;
  _crossSectionMap["DYee_600M800"] = 0.01510;
  _crossSectionMap["DYee_800M1000"] = 0.00375;
  _crossSectionMap["DYee_1000M1250"] = 0.001293;
  _crossSectionMap["DYee_1250M1500"] = 0.0003577;
  _crossSectionMap["DYee_1500M1750"] = 0.0001123;
  _crossSectionMap["DYee_1750M2000"] = 0.00003838;
  _crossSectionMap["DYee_2000M2250"] = 0.00001389; 
  _crossSectionMap["DYee_2250M2500"] = 0.000005226;
  _crossSectionMap["DYee_2500M2750"] = 0.000002017;
  _crossSectionMap["DYee_2750M3000"] = 0.0000007891;
  _crossSectionMap["DYee_3000M"] = 0.0000005039;

  // PI

  _crossSectionMap["PI60M200"] = 2.6976;
  _crossSectionMap["PI200M600"] = 0.12184;
  _crossSectionMap["PI600M1500"] = 0.0034933;
  _crossSectionMap["PI1500M2500"] = 0.000058593;
  _crossSectionMap["PI2500M"] = 0.0000022978;

  // TTbar
  _crossSectionMap["TT1"] = 112.9355;

  // DiBoson
	

  _crossSectionMap["DB_WW0"] = 12.41635703;
  _crossSectionMap["DB_WW1"] = 0.002719092028;
  _crossSectionMap["DB_WW2"] = 0.0000389295335;
  _crossSectionMap["DB_WZ0"] = 3.66658788;
  _crossSectionMap["DB_WZ1"] = 0.001433;
  _crossSectionMap["DB_WZ2"] = 0.0000530169675;
  _crossSectionMap["DB_ZZ0"] = 0.99243991;
  _crossSectionMap["DB_ZZ1"] = 0.000450257202;
  _crossSectionMap["DB_ZZ2"] = 0.00001003930774;

  _crossSectionMap["DB01"] = 0.05431;
  _crossSectionMap["DB02"] = 0.05431;
  _crossSectionMap["DB03"] = 0.05431;
  _crossSectionMap["DB04"] = 0.008149174;
  _crossSectionMap["DB05"] = 0.10301;
  _crossSectionMap["DB06"] = 0.070095446;
  _crossSectionMap["DB07"] = 0.10214419;
  _crossSectionMap["DB08"] = 0.145364895;
  _crossSectionMap["DB09"] = 0.069741995;
  _crossSectionMap["DB10"] = 0.59759;
  _crossSectionMap["DB11"] = 0.59770;
  _crossSectionMap["DB12"] = 0.59699;
  _crossSectionMap["DB13"] = 0.59737;
  _crossSectionMap["DB14"] = 0.59724;
  _crossSectionMap["DB15"] = 0.59772;
  _crossSectionMap["DB16"] = 0.59753;
  _crossSectionMap["DB17"] = 0.59745;
  _crossSectionMap["DB18"] = 0.59774;
  _crossSectionMap["DB19"] = 0.0062712657;
  _crossSectionMap["DB20"] = 0.11921823;
  _crossSectionMap["DB21"] = 0.138541277;
  _crossSectionMap["DB22"] = 0.018025875;
  _crossSectionMap["DB23"] = 0.229766032;
  _crossSectionMap["DB24"] = 0.278579994;
  _crossSectionMap["DB25"] = 0.017965125;
  _crossSectionMap["DB26"] = 0.22557978;
  _crossSectionMap["DB27"] = 0.29085273;
  _crossSectionMap["DB28"] = 0.010059072;
  _crossSectionMap["DB29"] = 0.171277792;
  _crossSectionMap["DB30"] = 0.19990311;
  _crossSectionMap["DB31"] = 0.029442798;
  _crossSectionMap["DB32"] = 0.335053884;
  _crossSectionMap["DB33"] = 0.41062049;
  _crossSectionMap["DB34"] = 0.029126772;
  _crossSectionMap["DB35"] = 0.330349602;
  _crossSectionMap["DB36"] = 0.41444592;

	// Z Prime
	_crossSectionMap["ZPrime_ee_SSM750"] = 0.48498;
	_crossSectionMap["ZPrime_ee_SSM1000"] = 0.12973;
	_crossSectionMap["ZPrime_ee_SSM1250"] = 0.041474;
	_crossSectionMap["ZPrime_ee_SSM1500"] = 0.015134;
	_crossSectionMap["ZPrime_ee_SSM1750"] = 0.0059881;
	_crossSectionMap["ZPrime_ee_SSM2000"] = 0.0025558;
  // ADD
  _crossSectionMap["ADDee120M300"] = 10.376;
  _crossSectionMap["ADDee300M600"] = 0.29089;
  _crossSectionMap["ADDee600M1200"] = 0.021123;
  _crossSectionMap["ADDeeM1200"] = 0.0030924;

  // HLZ
  _crossSectionMap["HLZ2500_300M600"] = 0.294442;
  _crossSectionMap["HLZ2500_600M1200"] = 0.0432168;
  _crossSectionMap["HLZ2500_M1200"] = 0.0142904;

  _crossSectionMap["HLZ3000_300M600"] = 0.290007;
  _crossSectionMap["HLZ3000_600M1200"] = 0.0276842;
  _crossSectionMap["HLZ3000_M1200"] = 0.00731725;

  _crossSectionMap["HLZ3500_120M300"] = 10.4432;
  _crossSectionMap["HLZ3500_300M600"] = 0.293895;
  _crossSectionMap["HLZ3500_600M1200"] = 0.0228558;
  _crossSectionMap["HLZ3500_M1200"] = 0.0039775;

  _crossSectionMap["HLZ4000_300M600"] = 0.293469;
  _crossSectionMap["HLZ4000_600M1200"] = 0.0215674;
  _crossSectionMap["HLZ4000_M1200"] = 0.002404;

  _crossSectionMap["HLZ50000_120M300"] = 10.4475;
  _crossSectionMap["HLZ50000_300M600"] = 0.295269;
  _crossSectionMap["HLZ50000_600M1200"] = 0.0203995;
  _crossSectionMap["HLZ50000_M1200"] = 0.000811633;


  // CI
  _crossSectionMap["CIm_LL_300M600"] = 2.7115e-01;
  _crossSectionMap["CIm_LL_600M1200"] = 2.6375e-02;
  _crossSectionMap["CIm_LL_M1200"] = 3.8245e-03;

  _crossSectionMap["CIm_LR_300M600"] = 2.8048e-01;
  _crossSectionMap["CIm_LR_600M1200"] = 3.1130e-02;
  _crossSectionMap["CIm_LR_M1200"] = 6.0555e-03;
}

void DataManager::initialiseArrays(){
	_ZPrimeFolders [0] = "mc12_8TeV.158021.Pythia8_AU2MSTW2008LO_Zprime_ee_SSM1500.merge.NTUP_SMWZ.e1242_s1469_s1470_r3542_r3549_p1067_tid00869354_00/";
	_ZPrimeFolders [1] = "mc12_8TeV.158021.Pythia8_AU2MSTW2008LO_Zprime_ee_SSM1500.merge.NTUP_SMWZ.e1242_s1469_s1470_r3542_r3549_p1328_tid01137246_00/";
	_ZPrimeFolders [2] = "mc12_8TeV.158022.Pythia8_AU2MSTW2008LO_Zprime_ee_SSM2000.merge.NTUP_SMWZ.e1242_s1469_s1470_r3542_r3549_p1067_tid00869353_00/";
	_ZPrimeFolders [3] = "mc12_8TeV.158022.Pythia8_AU2MSTW2008LO_Zprime_ee_SSM2000.merge.NTUP_SMWZ.e1242_s1469_s1470_r3542_r3549_p1328_tid01137247_00/";
	_ZPrimeFolders [4] = "mc12_8TeV.158023.Pythia8_AU2MSTW2008LO_Zprime_ee_SSM2500.merge.NTUP_SMWZ.e1242_s1469_s1470_r3542_r3549_p1067_tid00869352_00/";
	_ZPrimeFolders [5] = "mc12_8TeV.158023.Pythia8_AU2MSTW2008LO_Zprime_ee_SSM2500.merge.NTUP_SMWZ.e1242_s1469_s1470_r3542_r3549_p1328_tid01137248_00/";
	
	_ZPrimeBinNames[0] = "1500M_1";
	_ZPrimeBinNames[1] = "1500M_2";
	_ZPrimeBinNames[2] = "2000M_1";
	_ZPrimeBinNames[3] = "2000M_2";	
	_ZPrimeBinNames[4] = "2500M_1";	
	_ZPrimeBinNames[5] = "2500M_2";	

	_DYeeFolders[0]   = "mc12_8TeV.129504.PowhegPythia8_AU2CT10_DYee_120M180.merge.NTUP_SMWZ.e1248_s1469_s1470_r3752_r3549_p1067_tid00921410_00/";
	_DYeeFolders[1]   =  "mc12_8TeV.129505.PowhegPythia8_AU2CT10_DYee_180M250.merge.NTUP_SMWZ.e1248_s1469_s1470_r3542_r3549_p1005_tid00819147_00/";
	_DYeeFolders[2]   = "mc12_8TeV.129506.PowhegPythia8_AU2CT10_DYee_250M400.merge.NTUP_SMWZ.e1248_s1469_s1470_r3542_r3549_p1005_tid00819148_00/";
	_DYeeFolders[3]   = "mc12_8TeV.129507.PowhegPythia8_AU2CT10_DYee_400M600.merge.NTUP_SMWZ.e1248_s1469_s1470_r3542_r3549_p1005_tid00819149_00/";
	_DYeeFolders[4]   =  "mc12_8TeV.129508.PowhegPythia8_AU2CT10_DYee_600M800.merge.NTUP_SMWZ.e1248_s1469_s1470_r3542_r3549_p1005_tid00819150_00/";
	_DYeeFolders[5]   = "mc12_8TeV.129509.PowhegPythia8_AU2CT10_DYee_800M1000.merge.NTUP_SMWZ.e1248_s1469_s1470_r3542_r3549_p1005_tid00819151_00/";
	_DYeeFolders[6]   = "mc12_8TeV.129510.PowhegPythia8_AU2CT10_DYee_1000M1250.merge.NTUP_SMWZ.e1248_s1469_s1470_r3542_r3549_p1005_tid00819152_00/";
	_DYeeFolders[7]   = "mc12_8TeV.129511.PowhegPythia8_AU2CT10_DYee_1250M1500.merge.NTUP_SMWZ.e1248_s1469_s1470_r3542_r3549_p1005_tid00819153_00/";
	_DYeeFolders[8]   = "mc12_8TeV.129512.PowhegPythia8_AU2CT10_DYee_1500M1750.merge.NTUP_SMWZ.e1248_s1469_s1470_r3752_r3549_p1067_tid00921411_00/";
	_DYeeFolders[9]   = "mc12_8TeV.129513.PowhegPythia8_AU2CT10_DYee_1750M2000.merge.NTUP_SMWZ.e1248_s1469_s1470_r3542_r3549_p1005_tid00819155_00/";
	_DYeeFolders[10]  = "mc12_8TeV.129514.PowhegPythia8_AU2CT10_DYee_2000M2250.merge.NTUP_SMWZ.e1248_s1469_s1470_r3542_r3549_p1005_tid00819156_00/";
	_DYeeFolders[11]  = "mc12_8TeV.129515.PowhegPythia8_AU2CT10_DYee_2250M2500.merge.NTUP_SMWZ.e1248_s1469_s1470_r3542_r3549_p1005_tid00819157_00/";
	_DYeeFolders[12]  = "mc12_8TeV.129516.PowhegPythia8_AU2CT10_DYee_2500M2750.merge.NTUP_SMWZ.e1248_s1469_s1470_r3752_r3549_p1067_tid00921412_00/";
	_DYeeFolders[13]  = "mc12_8TeV.129517.PowhegPythia8_AU2CT10_DYee_2750M3000.merge.NTUP_SMWZ.e1248_s1469_s1470_r3752_r3549_p1067_tid00921413_00/";
	_DYeeFolders[14]  = "mc12_8TeV.129518.PowhegPythia8_AU2CT10_DYee_3000M.merge.NTUP_SMWZ.e1248_s1469_s1470_r3752_r3549_p1067_tid00921414_00";

	_DYeeBinNames[0]  = "120M180";
	_DYeeBinNames[1]  = "180M250";
	_DYeeBinNames[2]  = "250M400";
	_DYeeBinNames[3]  = "400M600"; 
	_DYeeBinNames[4]  = "600M800";
	_DYeeBinNames[5]  = "800M1000";
	_DYeeBinNames[6]  = "1000M1250";
	_DYeeBinNames[7]  = "1250M1500";
	_DYeeBinNames[8]  = "1500M1750";
	_DYeeBinNames[9]  = "1750M2000";
	_DYeeBinNames[10] = "2000M2250";
	_DYeeBinNames[11] = "2250M2500";
	_DYeeBinNames[12] = "2500M2750";
	_DYeeBinNames[13] = "2750M3000";
	_DYeeBinNames[14] = "3000M";

	_ADDeeFolders[0] = 
"mc12_8TeV.158548.Sherpa_CT10_ADDee_GRW_MS3500_120M300.merge.NTUP_SMWZ.e1496_a159_a171_r3549_p1328_tid01137762_00";
	_ADDeeFolders[1] = "mc12_8TeV.158554.Sherpa_CT10_ADDee_GRW_MS50000_120M300.merge.NTUP_SMWZ.e1496_a159_a171_r3549_p1328_tid01137768_00";
	_ADDeeFolders[2] = "mc12_8TeV.158549.Sherpa_CT10_ADDee_GRW_MS3500_300M600.merge.NTUP_SMWZ.e1496_a159_a171_r3549_p1328_tid01137763_00";
	_ADDeeFolders[3] = "mc12_8TeV.182242.Sherpa_CT10_ADDee_GRW_MS3250_300M600.merge.NTUP_SMWZ.e2168_a159_a171_r3549_p1328_tid01330874_00";
	_ADDeeFolders[4] = "mc12_8TeV.158556.Sherpa_CT10_ADDee_GRW_MS50000_600M1200.merge.NTUP_SMWZ.e1496_a159_a171_r3549_p1328_tid01137770_00";
	_ADDeeFolders[5] = "mc12_8TeV.182246.Sherpa_CT10_ADDee_GRW_MS3750_600M1200.merge.NTUP_SMWZ.e2168_a159_a171_r3549_p1328_tid01330878_00";
	_ADDeeFolders[6] = "mc12_8TeV.158557.Sherpa_CT10_ADDee_GRW_MS50000_M1200.merge.NTUP_SMWZ.e1496_a159_a171_r3549_p1328_tid01137771_00";
	_ADDeeFolders[7] = "mc12_8TeV.158551.Sherpa_CT10_ADDee_GRW_MS3500_M1200.merge.NTUP_SMWZ.e1496_a159_a171_r3549_p1328_tid01137765_00";

	_ADDeeBinNames[0] = "ADDee120M300";
	_ADDeeBinNames[1] = "ADDee120M300";
	_ADDeeBinNames[2] = "ADDee300M600";
	_ADDeeBinNames[3] = "ADDee300M600";
	_ADDeeBinNames[4] = "ADDee600M1200";
	_ADDeeBinNames[5] = "ADDee600M1200";
	_ADDeeBinNames[6] = "ADDeeM1200";
	_ADDeeBinNames[7] = "ADDeeM1200";

	_TTBarFolders[0] = "mc12_8TeV.105200.McAtNloJimmy_CT10_ttbar_LeptonFilter.merge.NTUP_SMWZ.e1193_s1469_s1470_r3542_r3549_p1328_tid01110896_00";
	_TTBarBinNames[0] = "TT1";

	_DBiWWFolders[0] = "mc12_8TeV.105985.Herwig_AUET2CTEQ6L1_WW.merge.NTUP_SMWZ.e1350_s1499_s1504_r3658_r3549_p1328_tid01110946_00";
	_DBiZZFolders[0] = 
"mc12_8TeV.105986.Herwig_AUET2CTEQ6L1_ZZ.merge.NTUP_SMWZ.e1350_s1499_s1504_r3658_r3549_p1328_tid01110586_00";
	_DBiWZFolders[0] =
"mc12_8TeV.105987.Herwig_AUET2CTEQ6L1_WZ.merge.NTUP_SMWZ.e1350_s1499_s1504_r3658_r3549_p1328_tid01110585_00";

	_DBWWFolders[0] = "mc12_8TeV.180451.Herwig_AUET2CTEQ6L1_WW_filter_enuenu_2pt10_400M1000.merge.NTUP_SMWZ.e1769_a159_a171_r3549_p1328_tid01196890_00";
	_DBWWFolders[1] = "mc12_8TeV.180452.Herwig_AUET2CTEQ6L1_WW_filter_enuenu_2pt10_1000M.merge.NTUP_SMWZ.e1784_a159_a171_r3549_p1328_tid01196891_00";
	
	_DBWWBinNames[0] = "WW400M1000";
	_DBWWBinNames[1] = "WW1000M";

	_DBWZFolders[0] = "mc12_8TeV.180453.Herwig_AUET2CTEQ6L1_WZ_filter_ee_2pt10_400M1000.merge.NTUP_SMWZ.e1769_a159_a171_r3549_p1328_tid01196894_00";
	_DBWZFolders[1] = "mc12_8TeV.180454.Herwig_AUET2CTEQ6L1_WZ_filter_ee_2pt10_1000M.merge.NTUP_SMWZ.e1784_a159_a171_r3549_p1328_tid01196895_00";
	
	_DBWZBinNames[0] = "WZ400M1000";
	_DBWZBinNames[1] = "WZ1000M";

	_DBZZFolders[0] = "mc12_8TeV.180455.Herwig_AUET2CTEQ6L1_ZZ_filter_ee_2pt10_400M1000.merge.NTUP_SMWZ.e1784_a159_a171_r3549_p1328_tid01196888_00";
	_DBZZFolders[1] = 
"mc12_8TeV.180456.Herwig_AUET2CTEQ6L1_ZZ_filter_ee_2pt10_1000M.merge.NTUP_SMWZ.e1784_a159_a171_r3549_p1328_tid01208093_00";

	_DBZZBinNames[0] = "ZZ400M1000";
	_DBZZBinNames[1] = "ZZ1000M";
}







#endif
