#include"../include/DataManager.h"
#include"../include/Utils.h"

int main(int argc, char* argv[]){
	std::vector<std::string> vec;
	vec.push_back("output/hist.root");
	DataManager d(vec);
	d.run();
}
