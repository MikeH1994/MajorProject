#include "../include/Utils.h"
#include<iostream>
#include<cmath>
#include<algorithm>
#include <sstream>
#include <stdio.h>
#include <string.h>

std::string Utils::MC_ROOT = "/scratch3/lduguid/Data/MC12/";

std::string Utils::MC_DYPO_FOLDER = (std::string)"mc12_8TeV.145963.Pythia8_AUMSTW2008LO_DYee_75M120."										+"merge.NTUP_SMWZ.e1223_s1469_s1470_r3542_r3549_p1328_tid01217889_00/";
std::string Utils::MC_DYPO_FILE = "NTUP_SMWZ.01217889._000001.root.1";

std::string Utils::MC_ZPRIME_FOLDER = (std::string)"mc12_8TeV.158021.Pythia8_AU2MSTW2008LO_Zprime_ee_SSM1500."							+"merge.NTUP_SMWZ.e1242_s1469_s1470_r3542_r3549_p1067_tid00869354_00/";
std::string Utils::MC_ZPRIME_FILE = "NTUP_SMWZ.00869354._000001.root.1";

std::string Utils::MC_DYEE_FOLDER = (std::string) "mc12_8TeV.129504.PowhegPythia8_AU2CT10_DYee_120M180.merge."	+"NTUP_SMWZ.e1248_s1469_s1470_r3752_r3549_p1067_tid00921410_00/";
std::string Utils::MC_DYEE_FILE = "NTUP_SMWZ.00921410._000001.root.1";

std::vector<std::string> Utils::getFileList(std::string arg1, std::string arg2,unsigned int maxLength){
	std::vector<std::string> vec;
	std::string path = MC_ROOT;
	if (arg1=="DYpo"){
		path+="DYpo/";
		if (arg2 == "0"){
			vec = getFiles(path,maxLength);
		}
		else if(arg2 == "1"){
			path+=MC_DYPO_FOLDER;
			vec = getFiles(path,maxLength);
		}
		else{
			path+=MC_DYPO_FOLDER + MC_DYPO_FILE;
			vec.push_back(path);
		}
	}
	else if (arg1 == "DYee"){
		path+="DYee/";
		if(arg2 == "0"){
			vec = getFiles(path,maxLength);
		}
		else if(arg2 == "1"){
			path+=MC_DYEE_FOLDER;
			vec = getFiles(path,maxLength);
		}
		else{
			path+=MC_DYEE_FOLDER + MC_DYEE_FILE;
			vec.push_back(path);
		}
	}	
	else if (arg1 == "ZPrime"){
		path+="ZPrime/";
		if(arg2 == "0"){
			vec = getFiles(path,maxLength);
		}
		else if(arg2 == "1"){
			path+=MC_DYEE_FOLDER;
			vec = getFiles(path,maxLength);
		}
		else{
			path+=MC_ZPRIME_FOLDER + MC_ZPRIME_FILE;
			vec.push_back(path);
		}
	}	
	return vec;
}

std::vector<std::string> Utils::getFiles(std::string directory, unsigned int maxLength){
	std::vector<std::string> returnedVector;
	getFilesInFolder(directory,returnedVector,maxLength);
	return returnedVector;
}

void Utils::getFilesInFolder(std::string directory, std::vector<std::string> & returnedVector,unsigned int maxLength){
	DIR *dir = opendir(directory.c_str());
	if (dir==NULL){
		std::cout<<"Invalid path "<<directory.c_str()<<" given"<<std::endl;
		throw 2;
	}
	dirent *entity = readdir(dir);
	while(entity!=NULL){
		if (strcmp(entity->d_name,".")!=0 && strcmp(entity->d_name,"..")!=0){
			if(entity->d_type == DT_DIR){
				getFilesInFolder(directory + "/" + (std::string) entity->d_name,returnedVector,maxLength);	
			}
			else if(returnedVector.size()<maxLength){
				returnedVector.push_back(directory +"/" +  (std::string) entity->d_name);
			}
		}
		entity = readdir(dir);
	}
	closedir(dir);
}

std::string Utils::getNthSubfolder(std::string directory, int n){
	DIR *dir = opendir(directory.c_str());
	if (dir==NULL){
		std::cout<<"Invalid filepath given"<<std::endl;
		closedir(dir);
		abort();
	}
	/*int nFilesInFolder = getNFolders(directory);
	if (n>=nFilesInFolder){
		std::cout<<"Folder "<<n<<" is out of range of folder "<<directory.c_str()<<" which has "<<nFilesInFolder<<std::endl;
		abort();
	}*/
	dirent *entity = readdir(dir);
	int nFolders = 0;
	std::string returnedPath;
	bool folderFound = false;
	while(entity!=NULL){
		if (strcmp(entity->d_name,".")!=0 && strcmp(entity->d_name,"..")!=0){
			if(entity->d_type == DT_DIR){
				std::cout<<entity->d_name<<std::endl;
				if (nFolders == n){
					folderFound = true;
					returnedPath = std::string(entity->d_name);
					break;
				}
				nFolders++;
			}
		}
		entity = readdir(dir);
	}
	closedir(dir);
	if (folderFound){
		return returnedPath;
	}
	std::cout<<"Folder number "<<n<<"in directory "<<directory<<" out of range; nFolders is "<<nFolders<<std::endl;
	throw 2;
}

int Utils::getNFolders(std::string directory){
DIR *dir = opendir(directory.c_str());
	if (dir==NULL){
		std::cout<<"Invalid filepath given"<<std::endl;
		closedir(dir);
		throw 2;
	}
	dirent *entity = readdir(dir);
	int nFolders = 0;

	while(entity!=NULL){
		if (strcmp(entity->d_name,".")!=0 && strcmp(entity->d_name,"..")!=0){
			if(entity->d_type == DT_DIR){
				nFolders++;
			}
		}
		entity = readdir(dir);
	}
	closedir(dir);
	return nFolders;
}

std::string Utils::intToString(int arg){
	std::string returnedString;
  std::ostringstream ss;
  ss << arg;
	return ss.str();
}

std::string Utils::doubleToString(double arg1){
	double arg = ((int) (100*arg1))/100.0;
	std::string returnedString;
  std::ostringstream ss;
  ss << arg;
	return ss.str();
}

int Utils::stringToInt(std::string arg){
		int i;
    std::stringstream ss(arg);
    ss >> i;
    if (ss.fail()) {
			std::cout<<"Exception in stringToInt() for argument "<<arg<<std::endl;
    }
    return i;
}
