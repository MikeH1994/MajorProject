#include"../include/Event.h"

Event::Event(){

}

Event::~Event(){

}

/*TClass *Event::Class()
{
  if (_Event_fgIsA == (TClass*)0){
			_Event_fgIsA = ROOT::GenerateInitInstance((const Event*)0x0)->GetClass();
	}
  return _Event_fgIsA;
}

void Event::Streamer(TBuffer &R__b)
{
   // Stream an object of class event.

   UInt_t R__s, R__c;
   if (R__b.IsReading()) {
      Version_t R__v = R__b.ReadVersion(&R__s, &R__c); if (R__v) { }
      TObject::Streamer(R__b);
      R__b >> ev_ID;
      objs.Streamer(R__b);
      R__b.CheckByteCount(R__s, R__c, Event::IsA());
   } else {
      R__c = R__b.WriteVersion(event::IsA(), kTRUE);
      TObject::Streamer(R__b);
      R__b << ev_ID;
      objs.Streamer(R__b);
      R__b.SetByteCount(R__c, kTRUE);
   }
}

void Event::ShowMembers(TMemberInspector &R__insp, char *R__parent)
{
      // Inspect the data members of an object of class event.

      TClass *R__cl = Event::IsA();
      Int_t R__ncp = strlen(R__parent);
      if (R__ncp || R__cl || R__insp.IsA()) { }
      R__insp.Inspect(R__cl, R__parent, "ev_ID", &ev_ID);
      R__insp.Inspect(R__cl, R__parent, "objs", &objs);
      objs.ShowMembers(R__insp, strcat(R__parent,"objs.")); R__parent[R__ncp] = 0;
      TObject::ShowMembers(R__insp, R__parent);
}
*/
