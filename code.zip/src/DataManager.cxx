#include "../include/DataManager.h"
#include "../include/Utils.h"
#include "../include/Event.h"
#include "../include/ElectronEventMarker.h"

#include <TPad.h>
#include <TGraph.h>
#include <TLegend.h>
#include <TF1.h>
#include <TLatex.h>
#include <TStyle.h>
#include <TLine.h>
#include <TCanvas.h>
#include <TMVA/Factory.h>
#include <TMVA/Reader.h>
#include <cmath>
#include <fstream>
#include <math.h>
# define M_PI 3.14159265358979323846

Double_t fitEnergyResolution(Double_t *x,Double_t *par){
	//par[0] = a; par[1] = b, par[2] = c
	double a = par[0];
	double b = par[1];
	double c = par[2];	
	return a/sqrt(x[0]) + b/x[0] + c;//
}

Double_t fitBreitWigner(Double_t* x, Double_t* par)
{
  Double_t arg1 = 14.0/22.0; // 2 over pi
  Double_t arg2 = par[1]*par[1]*par[2]*par[2]; //Gamma=par[1]  M=par[2]
  Double_t arg3 = ((x[0]*x[0]) - (par[2]*par[2]))*((x[0]*x[0]) - (par[2]*par[2]));
  Double_t arg4 = x[0]*x[0]*x[0]*x[0]*((par[1]*par[1])/(par[2]*par[2]));
  return par[0]*arg1*arg2/(arg3 + arg4);
}

Double_t fitf(Double_t *x,Double_t *par){
	//par[0] = sigma, par[1] = mu, par[2] = y offset
	
	return par[0]*exp(-0.5*pow( (x[0]-par[1])/par[2] ,2) + 0.01 );
}

Double_t fitExp(Double_t *x,Double_t *par){
	return par[0]*exp(-x[0]*par[1] + par[2]);
}

double getAsimovSignificance(double signal, double background){
	double k = (signal+background)*log(1+signal/background);
	double significance = sqrt( 2*( k-signal) );
	return significance;
}

double getAsimovError(double signal, double background, double dS, double dB){
	double increment = 0.001;
	double dZ_s = getAsimovSignificance(signal+increment,background) - getAsimovSignificance(signal-increment,background);
	double dZ_b = getAsimovSignificance(signal,background+increment) - getAsimovSignificance(signal,background - increment);
	double dZdS = dZ_s/(2*increment);
	double dZdB = dZ_b/(2*increment);
	double error = sqrt( pow(dZdS*dS,2) + pow(dZdB*dB,2) );
	return error;
}

void incrementHistogram(TH1D& hist,double x,double y){
	int bin = hist.FindBin(x);
	hist.SetBinContent(bin, y + hist.GetBinContent(bin));
}

void getValuesFromHist(TH1D *hist, double startVal, double endVal, double &value, double &error){
	value = 0;
	error = 0;
	int startBin = hist->FindBin(startVal);
	int endBin = hist->FindBin(endVal);
	for(int bin = startBin; bin<=endBin; bin++){
		value+=hist->GetBinContent(bin);
		error=sqrt(pow(hist->GetBinError(bin),2) + error*error);
	}
}

void copyHistogram(TH1D *input, TH1D *output){
	int outputBin;
	double newVal;	
	for(int inputBin = 1; inputBin<input->GetNbinsX()+1; inputBin++){
		outputBin = output->FindBin(input->GetBinCenter(inputBin));
		newVal = input->GetBinContent(inputBin) + output->GetBinContent(outputBin);
		output->SetBinContent(outputBin,newVal);
	}
}

TGraph *getGraphFromHist(TH1D* hist){
	double *x;
	double *y;
	TGraph *graph;
	int n = 0;
	for(int i = 1; i<hist->GetNbinsX()+1;i++){
		if (hist->GetBinContent(i)>0){
			n++;
		}
	}
	x = new double[n];
	y = new double[n];
	int index = 0;
		for(int i = 1; i<hist->GetNbinsX()+1;i++){
		if (hist->GetBinContent(i)>0 && index<n){
			x[index] = hist->GetBinCenter(i);
			y[index] = hist->GetBinContent(i);
			index++;
		}
	}
	graph = new TGraph(n,x,y);
	return graph;
}
	
const void DataManager::run(){
	TFile tFileDY("output/scaled/scaledDYeeErrors_4.root");	
	TFile tFileZ("output/scaled/scaledZPrimeErrors_4.root");
	TFile tFile("output/significance/asimovSignificance.root","RECREATE");
	std::string strArr[3] = {"1500Mh","2000Mh","2500Mh"};
	std::string strID[3] = {"Loose","Medium","Tight"};
	int centreArr[3] = {1500,2000,2500};
	for(int idCr = 0; idCr<3; idCr++){
		for(int i = 0; i<3; i++){
			TH1D* dyInput = (TH1D*) tFileDY.Get(("h" + strID[idCr]).c_str());
			TH1D* zInput = (TH1D*) tFileZ.Get((strArr[i] + strID[idCr]).c_str());
			int centre = centreArr[i];
			int startW = 4, endW = 1500, width = 2, bestWidth = 0;
			double signal = 0, background = 0,significance = 0, maxSig = 0,dMaxSig = 0;
			double ds = 0, db = 0, dTot = 0,dSig = 0;
		
			TH1D hSig(("hSig"+strArr[i] + strID[idCr]).c_str(),"Asimov Significance",endW-startW,startW,endW);

			for(width = startW; width<endW; width+=48){
				getValuesFromHist(zInput,centre-width/2.0,centre+width/2.0,signal,ds);
				getValuesFromHist(dyInput,centre-width/2.0,centre+width/2.0,background,db);
				significance = getAsimovSignificance(signal,background);
				dTot = getAsimovError(signal,background,ds,db);
				if(significance>maxSig){
					maxSig = significance;
					dMaxSig = dTot;
					bestWidth = width;
				}
				hSig.SetBinContent(width - startW + 1, significance);
				hSig.SetBinError(width - startW + 1, dTot);
			}
			int bin = 0;
			double val1,val2;
			bool marker = true;
			while(marker && bin<30){
				bin+=4;
				val1 = hSig.GetBinContent(bestWidth - startW + 1) - hSig.GetBinError(bestWidth - startW + 1);
				val2 = hSig.GetBinContent(bestWidth - startW + 1 + bin)
						 + hSig.GetBinError(bestWidth - startW + 1 + bin);
				if (val1>val2){
					marker = false;
				}
			}
			dSig = hSig.GetBinCenter(bestWidth-startW+1+bin) - hSig.GetBinCenter(bestWidth-startW+1);
			std::cout<<"Best Width: "<<bestWidth<<"+-"<<dSig<<"\tCentre: "<<centre<<"\t"<<strID[idCr].c_str()<<"\tSignificance " <<maxSig<<"+-"<<dMaxSig<<std::endl;

			hSig.SetTitle(("Approx Asimov Significance for " + Utils::intToString(centre) + " "+ strID[idCr] + ", best width: " + Utils::intToString(bestWidth) + " #pm " + Utils::intToString((int) dSig)).c_str());
			hSig.GetXaxis()->SetTitle("Bin width (GeV)");
			hSig.GetYaxis()->SetTitle("Asimov Signficance");
			hSig.Write();
		}
	}
	tFile.Write();
	std::cout<<"Done"<<std::endl;
}
