#include "../include/ElectronEventMarker.h"
#include "../include/ElectronEvent.h"
#include<cmath>
#include<vector>
#include<iostream>


ElectronEvent::ElectronEvent(int e1, int e2,ZPrimeClass *data):_e1(e1),_e2(e2),_data(data){
	_diPt = 0;
	_isGoodEvent = true;
	_truthOK = true;
	_cosThetaStar = 0;
	_invMass = 0;
	if (e1==e2 || e1 == -1 || e2 == -1){
		_isGoodEvent = false;
		return;
	}
	if ( (_data->el_pt->at(_e2)) > (_data->el_pt->at(_e1)) ){
		_e1 = e2;
		_e2 = e1;
	}
	_Pt1 = _data->el_pt->at(_e1);
	_Pt2 = _data->el_pt->at(_e2);
	_Px= _data->el_px->at(_e1) + _data->el_px->at(_e2);
	_Py= _data->el_py->at(_e1) + _data->el_py->at(_e2);
	_Pz= _data->el_pz->at(_e1) + _data->el_pz->at(_e2);
	_P2 = _Px*_Px + _Py*_Py + _Pz*_Pz;
	_E = _data->el_E->at(_e1) +  _data->el_E->at(_e2);
	_invMass = sqrt(_E*_E - _P2);
	checkEventIsGood();
}

ElectronEvent::~ElectronEvent(){

}

void ElectronEvent::checkEventIsGood(){
	//check if the invariant mass is less than 80GeV

	ElectronEventMarker::_EE_marker->_EEMARKER_TOT_EVENTS_1+=ElectronEventMarker::_EEMARKER_SCALEFACTOR;
	if (_invMass<8E4){
		_isGoodEvent = false;
		return;
	}

	ElectronEventMarker::_EE_marker->_EEMARKER_INVMASS_2+=ElectronEventMarker::_EEMARKER_SCALEFACTOR;
	//check if the transverse momenta is less than 30GeV
	if (_Pt1<3E4 || _Pt2<3E4){
		_isGoodEvent = false;
		return;
	}
	ElectronEventMarker::_EE_marker->_EEMARKER_PT_3+=ElectronEventMarker::_EEMARKER_SCALEFACTOR;

	if (_data->el_charge->at(_e1)!=-_data->el_charge->at(_e2)){
		_isGoodEvent = false;
		return;
	}
	ElectronEventMarker::_EE_marker->_EEMARKER_CHARGE_4+=ElectronEventMarker::_EEMARKER_SCALEFACTOR;
	
	/*double isolation1,isolation2;
	isolation1 = 0.007*_data->el_pt->at(_e1)/1000 + 5;
	isolation2 = 0.0022*_data->el_pt->at(_e2)/1000 + 6;

	if ((_data->el_Etcone20->at(_e1)/1000.0)>isolation1){
		_isGoodEvent = false;
		return;
	}
	if ((_data->el_Etcone20->at(_e2)/1000.0)>isolation2){
		_isGoodEvent = false;
		return;
	}
	ElectronEventMarker::_EE_marker->_EEMARKER_ISOLATION_5+=ElectronEventMarker::_EEMARKER_SCALEFACTOR;
	*/
}

int ElectronEvent::i(int arg){
	if (arg==0){
		return _e1;
	}
	else{
		return _e2;
	}
}


double ElectronEvent::getTruthMass(){
	double pt, eta, phi, E;
	pt = _data->el_truth_pt->at(_e1);
	eta = _data->el_truth_eta->at(_e1);
	phi = _data->el_truth_phi->at(_e1);
	E = _data->el_truth_E->at(_e1);
	TLorentzVector e1;
	e1.SetPtEtaPhiE(pt,eta,phi,E);

	pt = _data->el_truth_pt->at(_e2);
	eta = _data->el_truth_eta->at(_e2);
	phi = _data->el_truth_phi->at(_e2);
	E = _data->el_truth_E->at(_e2);
	TLorentzVector e2;
	e2.SetPtEtaPhiE(pt,eta,phi,E);

	TLorentzVector resultant = e1+e2;
	return resultant.M();
}
