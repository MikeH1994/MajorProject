#include "../include/ElectronEventMarker.h"
#include<iostream>
#include<cmath>
#include<fstream>

ElectronEventMarker::ElectronEventMarker(std::string name){
		_name = name;
		_EEMARKER_TOT_EVENTS_1 = 0;
		_EEMARKER_INVMASS_2 = 0;
		_EEMARKER_PT_3 = 0;
		_EEMARKER_CHARGE_4 = 0;
		_EEMARKER_ISOLATION_5 = 0;
}

void ElectronEventMarker::print(double totalEvents){
	std::cout<<"========\n"<<_name.c_str()<<"\n========"<<std::endl;

	std::cout<<"Criteria\tEfficiency (%)"<<std::endl;

	std::cout<<"Total Passing "<<_name.c_str()<<"\t"<<_EEMARKER_TOT_EVENTS_1/totalEvents*100<<"+-"<<sqrt(_EEMARKER_TOT_EVENTS_1)/totalEvents*100<<std::endl;

	std::cout<<"Invariant mass\t"<<_EEMARKER_INVMASS_2/totalEvents*100<<"+-"<<sqrt(_EEMARKER_INVMASS_2)/totalEvents*100<<std::endl;

	std::cout<<"Pt\t"<<_EEMARKER_PT_3/totalEvents*100<<"+-"<<sqrt(_EEMARKER_PT_3)/totalEvents*100<<std::endl;



	std::cout<<"Charge\t"<<_EEMARKER_CHARGE_4/totalEvents*100<<"+-"<<sqrt(_EEMARKER_CHARGE_4)/totalEvents*100<<std::endl;

	std::cout<<"Isolation\t"<<_EEMARKER_ISOLATION_5/totalEvents*100<<"+-"<<sqrt(_EEMARKER_ISOLATION_5)/totalEvents*100<<std::endl;
}

void ElectronEventMarker::writeToFile(double totalEvents, std::string title, std::string destination){
  std::ofstream fs;
  fs.open (destination.c_str(), std::fstream::app);
	fs<<"========\nName: "<<_name.c_str()<<", "<<title.c_str()<<"\n========"<<std::endl;
	fs<<"Total Passing "<<_name.c_str()<<"\t"<<_EEMARKER_TOT_EVENTS_1/totalEvents*100<<"+-"<<sqrt(_EEMARKER_TOT_EVENTS_1)/totalEvents*100<<std::endl;

	fs<<"Invariant mass\t"<<_EEMARKER_INVMASS_2/totalEvents*100<<"+-"<<sqrt(_EEMARKER_INVMASS_2)/totalEvents*100<<std::endl;

	fs<<"Pt\t"<<_EEMARKER_PT_3/totalEvents*100<<"+-"<<sqrt(_EEMARKER_PT_3)/totalEvents*100<<std::endl;

	fs<<"Charge\t"<<_EEMARKER_CHARGE_4/totalEvents*100<<"+-"<<sqrt(_EEMARKER_CHARGE_4)/totalEvents*100<<std::endl;

	fs<<"Isolation\t"<<_EEMARKER_ISOLATION_5/totalEvents*100<<"+-"<<sqrt(_EEMARKER_ISOLATION_5)/totalEvents*100<<std::endl;

	fs.close();
}

void ElectronEventMarker::reset(){
		_EEMARKER_TOT_EVENTS_1 = 0;
		_EEMARKER_INVMASS_2 = 0;
		_EEMARKER_PT_3 = 0;
		_EEMARKER_CHARGE_4 = 0;
		_EEMARKER_ISOLATION_5 = 0;
}

void ElectronEventMarker::printAll(double totalEvents){
	_EE_looseMarker->print(totalEvents);
	_EE_mediumMarker->print(totalEvents);
	_EE_tightMarker->print(totalEvents);
}	
void ElectronEventMarker::writeAllToFile(double totalEvents, std::string title, std::string destination){
	_EE_looseMarker->writeToFile(totalEvents,title,destination);
	_EE_mediumMarker->writeToFile(totalEvents,title,destination);
	_EE_tightMarker->writeToFile(totalEvents,title,destination);
}

void ElectronEventMarker::resetAll(){
	_EE_looseMarker->reset();
	_EE_mediumMarker->reset();
	_EE_tightMarker->reset();
}

ElectronEventMarker* ElectronEventMarker::_EE_looseMarker = new ElectronEventMarker("loose");
ElectronEventMarker* ElectronEventMarker::_EE_mediumMarker = new ElectronEventMarker("medium");
ElectronEventMarker* ElectronEventMarker::_EE_tightMarker = new ElectronEventMarker("tight");
ElectronEventMarker* ElectronEventMarker::_EE_marker = _EE_looseMarker;
double ElectronEventMarker::_EEMARKER_SCALEFACTOR = 1;
